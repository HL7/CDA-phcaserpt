This readme is included in a zip file that packages the ballot package of:


Publication title:                               HL7 CDA� R2 Implementation Guide: Public Health Case Report, Release 2 - the Electronic Initial Case Report - Edition 4 - US Realm
Edition:                                         4.0.0
Realm:                                           US Realm
Release status:                                  Standard for Trial Use (STU)
JIRA Specification key:                          phcaserpt
Version:                                         4.0.0
Publication date:                                2025-12
Prepared by:                                     Public Health Work Group

The package was prepared by Lantana Consulting Group, LLC.

Contents of the package:
========================
_readme.txt                                                             									This file

CDAR2_IG_PHCASERPT_E4_S4_Vol1_Introductory_Material.pdf                										Implementation Guide Introductory MaterialCDAR2_IG_PHCASERPT_E4_S4_Vol2_Templates_and_Supporting.pdf             										Implementation Guide Template Library and Supporting Material

XML and Related files (Schematron, sample, html, stylesheet) are housed on the HL7 GitHub: https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0

https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0/examples/samples/CDAR2_IG_PHCASERPT_E4_S4_SAMPLE.xml				Sample file
https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0/examples/samples/CDAR2_IG_PHCASERPT_E4_S4_SAMPLE_EXTERNAL_ENCOUNTER.xml	Sample file to represent an external encounter
https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0/examples/samples/CDAR2_IG_PHCASERPT_E4_S4_SAMPLE_MANUAL.xml			Sample file to represent a manual trigger

https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0/validation/CDAR2_IG_PHCASERPT_E4_S4_SCHEMATRON.sch				Schematron file
https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0/validation/CDAR2_IG_PHCASERPT_E4_S4_VOCABULARY.xml				Schematron vocabulary file

https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcaserpt-4.0.0/transform/CDAR2_IG_PHCASERPT_E4_S4.xsl					Stylesheet for rendering


The latest CDA Schema is located on the HL7 GitHub site: https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions/SDTC


Questions 
========================
Direct questions about the implementation guide to the HL7 Public Health Working Group.
                                
December 2025