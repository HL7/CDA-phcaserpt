This readme is included in a zip file that packages the ballot package of:


Publication title:                               HL7 CDA� R2 Implementation Guide: Reportability Response File, Release 1 � US Realm Edition 2.0.0
Edition:                                         2.0.0
Realm:                                           US Realm
Release status:                                  Standard for Trial Use (STU)
JIRA Specification key:                          phcr-rr
Version:                                         2.0.0
Publication date:                                2025-12
Prepared by:                                     Public Health Work Group

The package was prepared by Lantana Consulting Group, LLC.

Contents of the package:
========================
_readme.txt                                                             							This file

CDAR2_IG_PHCR_R2_RR_S2_Vol1_Introductory_Material.pdf										Implementation Guide Introductory Material
CDAR2_IG_PHCR_R2_RR_S2_Vol2_Templates_and_Supporting_Material.pdf								Implementation Guide Template Library and Supporting Material
CDAR2_IG_PHCR_R2_RR_S2_Vol3_Creator_Guidance.pdf										Informative creator guidance for generating narrative
CDAR2_IG_PHCR_R2_RR_S2_Vol4_Receiver_Guidance.pdf										Informative receiver guidance for visualization of narrative

-- Support files --                      
                
XML and Related files (Schematron, sample, html, stylesheet) are housed on the HL7 GitHub: https://github.com/HL7/CDA-phcaserpt/tree/main/CDA-phcr-rr-2.0.0 
	
https://github.com/HL7/CDA-phcaserpt/blob/main/CDA-phcr-rr-2.0.0/examples/samples/CDAR2_IG_PHCR_R2_RR_S2_SAMPLE.xml		Sample file
https://github.com/HL7/CDA-phcaserpt/blob/main/CDA-phcr-rr-2.0.0/examples/samples/CDAR2_IG_PHCR_R2_RR_S2_SAMPLE_ERROR.xml	Sample file showing an error

https://github.com/HL7/CDA-phcaserpt/blob/main/CDA-phcr-rr-2.0.0/validation/CDAR2_IG_PHCR_R2_RR_S2_SCHEMATRON.sch		Schematron file
https://github.com/HL7/CDA-phcaserpt/blob/main/CDA-phcr-rr-2.0.0/validation/CDAR2_IG_PHCR_R2_RR_S2_VOC.xml			Schematron vocabulary file

https://github.com/HL7/CDA-phcaserpt/blob/main/CDA-phcr-rr-2.0.0/transforms/CDAR2_IG_PHCR_R2_RR_S2_STYLESHEET.xsl		Stylesheet for rendering

The latest CDA Schema is located on the HL7 GitHub site: https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions 
	
	
Questions 
========================
Direct questions about the implementation guide to the HL7 Public Health Working Group.
                                
December 2025